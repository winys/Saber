<template>
    <div>
        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>

        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>
        <div class="foo">dasdsads</div>
    </div>
</template>
<style>
    .foo{
        padding :20px;
    }
</style>